Package include:

- 28 meshes in low poly (flat) style
- 17 tree models
- 7 small greens meshes (grass, plant, mushrooms etc.)

- Summer, Winter, Autumn Red, Autumn Orange prefab pack
- 3 Demo scenes with terrains
